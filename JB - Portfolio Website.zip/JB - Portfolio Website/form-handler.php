<?php
// Include PHPMailer classes
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

// Load Composer's autoloader
require 'vendor/autoload.php';

// Form data
$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$subject = $_POST['subject'] ?? '';
$message = $_POST['message'] ?? '';

// Validation
$errors = [];

if (empty($name)) {
    $errors[] = "Naam is verplicht";
}

if (empty($email)) {
    $errors[] = "E-mail is verplicht";
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "E-mail is ongeldig";
}

if (empty($subject)) {
    $errors[] = "Onderwerp is verplicht";
}

if (empty($message)) {
    $errors[] = "Bericht is verplicht";
}

// Response data
$response = [];

// If there are errors, return them
if (!empty($errors)) {
    $response['success'] = false;
    $response['errors'] = $errors;
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

// Create a new PHPMailer instance
$mail = new PHPMailer(true);

try {
    // Enable logging to server error log instead of output
    $mail->SMTPDebug = 0;                                 // Disable debug output to browser
    // If you need debugging, use this instead:
    // $mail->SMTPDebug = 2;
    // $mail->Debugoutput = function($str, $level) {
    //     error_log("PHPMailer: $str");
    // };
    
    // Server settings
    $mail->isSMTP();                                      // Use SMTP
    $mail->Host       = 'smtp.gmail.com';                 // Replace with your SMTP server
    $mail->SMTPAuth   = true;                             // Enable SMTP authentication
    $mail->Username   = 'jealbalatbat1707@gmail.com';     // Your email address
    $mail->Password   = '@$017AsO';           // Your email password or app password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;   // Enable TLS encryption
    $mail->Port       = 587;                              // TCP port to connect to

    // Recipients
    $mail->setFrom('jealbalatbat1707@gmail.com', 'Contact Form');
    $mail->addAddress('jealbalatbat1707@gmail.com');     // Add a recipient
    $mail->addReplyTo($email, $name);                    // Set reply-to address

    // Content
    $mail->isHTML(false);                                // Set email format to plain text
    $mail->Subject = "Contact Form: $subject";
    
    // Prepare email content
    $email_body = "Naam: $name\n";
    $email_body .= "E-mail: $email\n";
    $email_body .= "Onderwerp: $subject\n\n";
    $email_body .= "Bericht:\n$message\n";
    
    $mail->Body = $email_body;

    // Send email
    $mail->send();
    
    $response['success'] = true;
    $response['message'] = "Bericht succesvol verzonden!";
} catch (Exception $e) {
    // Log the error to server error log
    error_log("PHPMailer Error: {$mail->ErrorInfo}");
    
    $response['success'] = false;
    $response['errors'] = ["Er is een probleem opgetreden bij het verzenden van uw bericht. Probeer het later opnieuw."];
}

// Make sure nothing is output before this point
// Clear any previous output
if (ob_get_length()) ob_clean();

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
exit;
?>