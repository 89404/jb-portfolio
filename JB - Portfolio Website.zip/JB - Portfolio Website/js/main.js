// Dark mode toggle
const darkModeToggle = document.getElementById('darkModeToggle');
const html = document.documentElement;

// Check for saved theme preference
if (localStorage.theme === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
  html.classList.add('dark');
} else {
  html.classList.remove('dark');
}

// Toggle dark mode
darkModeToggle?.addEventListener('click', () => {
  html.classList.toggle('dark');
  localStorage.theme = html.classList.contains('dark') ? 'dark' : 'light';
});

// Mobile menu toggle
const mobileMenuButton = document.getElementById('mobileMenuButton');
const mobileMenu = document.getElementById('mobileMenu');

mobileMenuButton?.addEventListener('click', () => {
  mobileMenu.classList.toggle('hidden');
});

// Carousel functionality for projecten.html
const carouselInner = document.getElementById('carouselInner');
const prevBtn = document.getElementById('carouselPrev');
const nextBtn = document.getElementById('carouselNext');

function restartTypewriterAnimation(card) {
    // Remove and re-add the animation classes to restart them
    const title = card.querySelector('.typewriter');
    const desc = card.querySelector('.typewriter-multiline');
    if (title) {
        title.classList.remove('typewriter');
        void title.offsetWidth; // force reflow
        title.classList.add('typewriter');
    }
    if (desc) {
        desc.classList.remove('typewriter-multiline');
        void desc.offsetWidth; // force reflow
        desc.classList.add('typewriter-multiline');
    }
}

if (carouselInner && prevBtn && nextBtn) {
    let currentIndex = 0;
    const total = carouselInner.children.length;
    function updateCarousel() {
        carouselInner.style.transform = `translateX(-${currentIndex * 100}%)`;
        // Restart typewriter animation for the visible card
        const cards = carouselInner.children;
        for (let i = 0; i < cards.length; i++) {
            if (i === currentIndex) {
                restartTypewriterAnimation(cards[i]);
            }
        }
    }
    prevBtn.addEventListener('click', () => {
        currentIndex = (currentIndex - 1 + total) % total;
        updateCarousel();
    });
    nextBtn.addEventListener('click', () => {
        currentIndex = (currentIndex + 1) % total;
        updateCarousel();
    });
    // Initial animation on first card
    updateCarousel();
}

// Animate skill bars in over-mij.html
window.addEventListener('DOMContentLoaded', () => {
  const skillBars = document.querySelectorAll('.skill-bar');
  skillBars.forEach(bar => {
    const percentage = bar.getAttribute('data-percentage');
    bar.style.transition = 'width 1.5s cubic-bezier(0.4, 0, 0.2, 1)';
    setTimeout(() => {
      bar.style.width = percentage + '%';
    }, 300); // slight delay for effect
  });
});

// Contact form handling
document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            // Only prevent default if fetch is available
            if (window.fetch) {
                e.preventDefault();
                
                const formData = new FormData(contactForm);
                const submitButton = document.getElementById('submitButton');
                const formStatus = document.getElementById('formStatus');
                
                // Disable button and show loading state
                submitButton.disabled = true;
                submitButton.textContent = 'Verzenden...';
                formStatus.className = 'hidden';
                
                fetch('form-handler.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => {
                    // Check if response is OK before trying to parse JSON
                    if (!response.ok) {
                        throw new Error('Server returned ' + response.status + ' ' + response.statusText);
                    }
                    return response.text().then(text => {
                        try {
                            return JSON.parse(text);
                        } catch (e) {
                            console.error('Invalid JSON response:', text);
                            throw new Error('Invalid server response');
                        }
                    });
                })
                .then(data => {
                    // Re-enable button
                    submitButton.disabled = false;
                    submitButton.textContent = 'Verstuur Bericht';
                    
                    // Show response message
                    formStatus.className = data.success ? 
                        'p-4 mb-4 text-sm rounded-lg bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300' : 
                        'p-4 mb-4 text-sm rounded-lg bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
                    
                    if (data.success) {
                        formStatus.textContent = data.message;
                        contactForm.reset(); // Clear the form
                    } else {
                        formStatus.textContent = data.errors.join(', ');
                    }
                    
                    formStatus.classList.remove('hidden');
                })
                .catch(error => {
                    // Handle error
                    submitButton.disabled = false;
                    submitButton.textContent = 'Verstuur Bericht';
                    formStatus.className = 'p-4 mb-4 text-sm rounded-lg bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
                    formStatus.textContent = 'Er is een fout opgetreden: ' + error.message;
                    formStatus.classList.remove('hidden');
                    console.error('Error:', error);
                });
            }
            // If fetch isn't available, the form will submit normally using the action and method attributes
        });
    }
});